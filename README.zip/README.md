[![Build](https://github.com/Ftujio-s-Organization/Finance-Manager/actions/workflows/main.yml/badge.svg?branch=master)](https://github.com/Ftujio-s-Organization/Finance-Manager/actions/workflows/main.yml) [![codecov](https://codecov.io/gh/Ftujio-s-Organization/Finance-Manager/branch/master/graph/badge.svg?token=DI0COVRUK7)](https://codecov.io/gh/Ftujio-s-Organization/Finance-Manager)

# Finance Manager
Desktop app for managing your finances built with **Electron** and **Angular**

### TODO:
- [x] Setup working environment
- [x] Setup app dependencies
- [x] Create basic app architecture
- [x] Create basic app layout
- [ ] Add core functionality
